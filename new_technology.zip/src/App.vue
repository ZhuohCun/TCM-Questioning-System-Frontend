<template>
  <div id="app">
    <nav class="nav-bar">
      <div class="nav-links">
        <router-link to="/" class="nav-link">首页</router-link>
        <template v-if="store.state.isLoggedIn">
          <router-link to="/chat" class="nav-link">智能问答</router-link>
          <router-link to="/acupoint" class="nav-link">穴位信息</router-link>
          <router-link to="/knowledge-graph" class="nav-link">知识图谱</router-link>
        </template>
      </div>
      <div class="auth-links">
        <template v-if="!store.state.isLoggedIn">
          <router-link to="/login" class="auth-link">登录</router-link>
          <router-link to="/register" class="auth-link">注册</router-link>
        </template>
        <template v-else>
          <span class="welcome">欢迎使用</span>
          <a href="#" class="auth-link" @click.prevent="handleLogout">退出</a>
        </template>
      </div>
    </nav>
    <router-view/>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'

const store = useStore()
const router = useRouter()

onMounted(() => {
  // 检查本地存储的token
  const token = localStorage.getItem('token')
  if (token) {
    store.commit('setToken', token)
    store.commit('setLoggedIn', true)
  }
})

const handleLogout = () => {
  store.commit('logout')
  router.push('/login')
}
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

.nav-bar {
  padding: 1rem 2rem;
  background-color: #fff;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
}

.nav-links {
  display: flex;
  gap: 1.5rem;
}

.auth-links {
  display: flex;
  gap: 1rem;
  align-items: center;
}

.nav-link, .auth-link {
  text-decoration: none;
  color: #2c3e50;
  font-weight: 500;
  padding: 0.5rem 0.8rem;
  border-radius: 4px;
  transition: all 0.3s ease;
}

.nav-link:hover, .auth-link:hover {
  color: #42b983;
  background-color: rgba(66, 185, 131, 0.1);
}

.router-link-active {
  color: #42b983;
  font-weight: bold;
}

.welcome {
  color: #666;
  margin-right: 1rem;
}

/* 为了避免导航栏遮挡内容 */
#app > :nth-child(2) {
  margin-top: 64px;
  min-height: calc(100vh - 64px);
}

@media (max-width: 768px) {
  .nav-bar {
    padding: 1rem;
    flex-direction: column;
    gap: 1rem;
  }

  .nav-links, .auth-links {
    width: 100%;
    justify-content: center;
  }
}
</style>
