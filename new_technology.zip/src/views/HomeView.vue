npm<template>
  <div class="page-container">
    <div class="hero-container">
      <div class="content-wrapper">
        <h1>TCM中医针灸问答系统</h1>
        <p class="subtitle">智能辅助诊疗，专业针灸知识查询</p>
        <router-link 
          :to="store.state.isLoggedIn ? '/chat' : '/login'" 
          class="start-btn"
        >
          开始问诊
        </router-link>
      </div>
    </div>

    <div class="content-wrapper">
      <div class="features-section">
        <div class="feature-card">
          <div class="icon-box">
            <el-icon><ChatRound /></el-icon>
          </div>
          <h3>智能问答</h3>
          <p>基于AI的智能诊疗助手，为您提供专业的健康咨询服务</p>
        </div>
        <div class="feature-card">
          <div class="icon-box">
            <el-icon><Search /></el-icon>
          </div>
          <h3>穴位查询</h3>
          <p>详细的穴位信息库，帮助您了解中医针灸知识</p>
        </div>
        <div class="feature-card">
          <div class="icon-box">
            <el-icon><Document /></el-icon>
          </div>
          <h3>对话记录</h3>
          <p>完整保存您的问诊记录，方便随时查看和回顾</p>
        </div>
      </div>

      <div class="timeline-section">
        <h2>系统发展历程</h2>
        <div class="timeline">
          <div class="timeline-item">
            <div class="timeline-point"></div>
            <div class="timeline-content">
              <span class="date">2024年12月</span>
              <h3>穴位查询功能上线</h3>
              <p>新增中医穴位查询功能，提供详细的穴位信息和专业知识库</p>
            </div>
          </div>
          <div class="timeline-item">
            <div class="timeline-point"></div>
            <div class="timeline-content">
              <span class="date">2024年12月</span>
              <h3>对话记录保存功能</h3>
              <p>支持自动保存问诊记录，方便用户随时查看历史对话内容</p>
            </div>
          </div>
          <div class="timeline-item">
            <div class="timeline-point"></div>
            <div class="timeline-content">
              <span class="date">2024年12月</span>
              <h3>智能问答上线</h3>
              <p>升级AI对话模型，提供更准确的中医诊疗咨询服务</p>
            </div>
          </div>
          <div class="timeline-item">
            <div class="timeline-point"></div>
            <div class="timeline-content">
              <span class="date">2024年10月</span>
              <h3>系统正式new了一个project</h3>
              <p>中医针灸问答系统前后端正式开启</p>
            </div>
          </div>
        </div>
      </div>

      <div class="disclaimer-section">
        <div class="disclaimer-card">
          <div class="icon-box">
            <el-icon><Warning /></el-icon>
          </div>
          <h3>免责声明</h3>
          <div class="disclaimer-content">
            <p>本系统仅供参考学习使用，不构成医疗建议。如有健康问题，请务必在专业医生指导下进行诊疗。</p>
            <ul>
              <li>系统提供的信息仅供参考，不能替代专业医生的诊断和建议</li>
              <li>针灸治疗应在专业中医师指导下进行，请勿自行尝试</li>
              <li>如遇紧急情况，请立即就医</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useStore } from 'vuex'
import { ChatRound, Search, Document, Warning } from '@element-plus/icons-vue'

const store = useStore()
</script>

<style scoped lang="scss">
.page-container {
  min-height: 200vh;
  margin-top: 111px;
  background: #f5f7fa;
}

.hero-container {
  background: #007AFF;
  padding: 180px 0;
  text-align: center;
  color: white;
}

.content-wrapper {
  width: 1200px;
  margin: 0 auto;
}

h1 {
  font-size: 48px;
  font-weight: bold;
  margin-bottom: 24px;
}

.subtitle {
  font-size: 20px;
  opacity: 0.9;
  margin-bottom: 48px;
}

.start-btn {
  display: inline-block;
  padding: 16px 60px;
  background: white;
  color: #007AFF;
  border-radius: 30px;
  font-size: 20px;
  font-weight: 600;
  text-decoration: none;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
  }
}

.features-section {
  display: flex;
  justify-content: space-between;
  margin: -40px auto 60px;
  gap: 30px;
}

.feature-card {
  flex: 1;
  background: white;
  border-radius: 20px;
  padding: 40px;
  text-align: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

  .icon-box {
    width: 80px;
    height: 80px;
    margin: 0 auto 24px;
    background: rgba(0, 122, 255, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;

    .el-icon {
      font-size: 40px;
      color: #007AFF;
    }
  }

  h3 {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 20px;
    color: #333;
  }

  p {
    font-size: 16px;
    line-height: 1.6;
    color: #666;
  }
}

.disclaimer-card {
  background: white;
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

  .icon-box {
    width: 60px;
    height: 60px;
    margin: 0 auto 20px;
    background: rgba(255, 215, 0, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;

    .el-icon {
      font-size: 30px;
      color: #FFD700;
    }
  }

  h3 {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 20px;
    color: #333;
    text-align: center;
  }

  .disclaimer-content {
    text-align: left;
    
    p {
      font-size: 16px;
      line-height: 1.6;
      color: #666;
      margin-bottom: 20px;
    }

    ul {
      list-style-type: disc;
      padding-left: 20px;
      margin-bottom: 0;
      
      li {
        font-size: 14px;
        line-height: 1.8;
        color: #666;
        margin-bottom: 8px;
        
        &:last-child {
          margin-bottom: 0;
        }
      }
    }
  }
}

.timeline-section {
  margin: 80px 0;
  padding: 60px;
  background: white;
  border-radius: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

  h2 {
    text-align: center;
    font-size: 32px;
    color: #333;
    margin-bottom: 60px;
  }
}

.timeline {
  position: relative;
  padding: 20px 0;

  &::before {
    content: '';
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    width: 2px;
    height: 100%;
    background: #007AFF;
  }
}

.timeline-item {
  position: relative;
  margin-bottom: 60px;
  width: 50%;
  padding-right: 50px;

  &:nth-child(even) {
    margin-left: auto;
    padding-right: 0;
    padding-left: 50px;

    .timeline-content {
      text-align: left;
    }
  }

  &:last-child {
    margin-bottom: 0;
  }
}

.timeline-point {
  position: absolute;
  right: -9px;
  top: 0;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #007AFF;
  border: 4px solid white;
  box-shadow: 0 0 0 2px #007AFF;

  .timeline-item:nth-child(even) & {
    right: auto;
    left: -11px;
  }
}

.timeline-content {
  background: #f8f9fa;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);

  .date {
    display: inline-block;
    padding: 4px 12px;
    background: #007AFF;
    color: white;
    border-radius: 15px;
    font-size: 14px;
    margin-bottom: 15px;
  }

  h3 {
    color: #333;
    font-size: 20px;
    margin-bottom: 10px;
  }

  p {
    color: #666;
    font-size: 16px;
    line-height: 1.6;
    margin: 0;
  }
}
</style>